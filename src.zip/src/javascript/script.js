console.log('Gioco del tris');

let play = function(r,c) {
    console.log(`Hai premuto sulla casella: ${r} ${c}`);
}